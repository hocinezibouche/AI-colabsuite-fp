"use client";

import { Empty } from "@/components/ui/empty";

const Error = () => {
  return ( 
    <Empty label="Something went wrong." />
   );
}
 
export default Error;
